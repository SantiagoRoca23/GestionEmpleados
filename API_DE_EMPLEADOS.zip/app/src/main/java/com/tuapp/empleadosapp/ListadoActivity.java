package com.tuapp.empleadosapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListadoActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private EmpleadoAdapter adapter;
    private List<Empleado> empleados = new ArrayList<>();
    private static final int REQ_ADD = 1, REQ_EDIT = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado);

        // Inicializar RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        if (recyclerView == null) {
            Toast.makeText(this, "Error: RecyclerView no encontrado", Toast.LENGTH_LONG).show();
            return;
        }

        // Configurar LayoutManager
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Inicializar Adapter
        adapter = new EmpleadoAdapter(empleados, new EmpleadoAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Empleado empleado) {
                try {
                    Intent intent = new Intent(ListadoActivity.this, DetalleActivity.class);
                    intent.putExtra("empleado", empleado);
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(ListadoActivity.this, "Error al abrir detalles", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onEditClick(Empleado empleado, int position) {
                try {
                    Intent intent = new Intent(ListadoActivity.this, FormularioActivity.class);
                    intent.putExtra("empleado", empleado);
                    intent.putExtra("position", position);
                    startActivityForResult(intent, REQ_EDIT);
                } catch (Exception e) {
                    Toast.makeText(ListadoActivity.this, "Error al editar", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onDeleteClick(Empleado empleado, int position) {
                new AlertDialog.Builder(ListadoActivity.this)
                        .setTitle("Eliminar")
                        .setMessage("¿Seguro que deseas eliminar este empleado?")
                        .setPositiveButton("Sí", (dialog, which) -> {
                            try {
                                eliminarEmpleado(empleado.getId(), position);
                            } catch (Exception e) {
                                Toast.makeText(ListadoActivity.this, "Error al eliminar", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton("No", null)
                        .show();
            }
        });

        recyclerView.setAdapter(adapter);

        // Configurar FAB
        FloatingActionButton fab = findViewById(R.id.fabAgregar);
        if (fab != null) {
            fab.setOnClickListener(v -> {
                try {
                    Intent intent = new Intent(ListadoActivity.this, FormularioActivity.class);
                    startActivityForResult(intent, REQ_ADD);
                } catch (Exception e) {
                    Toast.makeText(ListadoActivity.this, "Error al abrir formulario", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // Cargar datos
        cargarEmpleados();
    }

    private void cargarEmpleados() {
        try {
            EmpleadoApi api = ApiClient.getRetrofit().create(EmpleadoApi.class);
            api.getEmpleados().enqueue(new Callback<List<Empleado>>() {
                @Override
                public void onResponse(Call<List<Empleado>> call, Response<List<Empleado>> response) {
                    if (response.isSuccessful() && response.body() != null) {
                        empleados.clear();
                        empleados.addAll(response.body());
                        adapter.notifyDataSetChanged();
                    } else {
                        String errorMsg = "Error al cargar empleados: " + response.code();
                        Toast.makeText(ListadoActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<List<Empleado>> call, Throwable t) {
                    String errorMsg = "Error de red: " + t.getMessage();
                    Toast.makeText(ListadoActivity.this, errorMsg, Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, "Error al inicializar la API: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void eliminarEmpleado(int id, int position) {
        try {
            EmpleadoApi api = ApiClient.getRetrofit().create(EmpleadoApi.class);
            api.eliminarEmpleado(id).enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                    if (response.isSuccessful()) {
                        empleados.remove(position);
                        adapter.notifyItemRemoved(position);
                        Toast.makeText(ListadoActivity.this, "Empleado eliminado", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(ListadoActivity.this, "Error al eliminar empleado", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Toast.makeText(ListadoActivity.this, "Error de red al eliminar", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (Exception e) {
            Toast.makeText(this, "Error al eliminar: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null) {
            try {
                Empleado empleado = (Empleado) data.getSerializableExtra("empleado");
                if (empleado != null) {
                    if (requestCode == REQ_ADD) {
                        empleados.add(empleado);
                        adapter.notifyItemInserted(empleados.size() - 1);
                    } else if (requestCode == REQ_EDIT) {
                        int pos = data.getIntExtra("position", -1);
                        if (pos != -1 && pos < empleados.size()) {
                            empleados.set(pos, empleado);
                            adapter.notifyItemChanged(pos);
                        }
                    }
                }
            } catch (Exception e) {
                Toast.makeText(this, "Error al procesar el resultado: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }
}
