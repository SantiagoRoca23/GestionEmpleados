package com.tuapp.empleadosapp;


import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

public class FormularioActivity extends AppCompatActivity {
    private EditText etNombre, etTipo, etEdad, etImagen;
    private Empleado empleado;
    private int position = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        etNombre = findViewById(R.id.etNombre);
        etTipo = findViewById(R.id.etTipo);
        etEdad = findViewById(R.id.etEdad);
        etImagen = findViewById(R.id.etImagen);

        if (getIntent().hasExtra("empleado")) {
            empleado = (Empleado) getIntent().getSerializableExtra("empleado");
            position = getIntent().getIntExtra("position", -1);
            etNombre.setText(empleado.getNombre());
            etTipo.setText(empleado.getTipo());
            etEdad.setText(String.valueOf(empleado.getEdad()));
            etImagen.setText(empleado.getImagen());
        }

        Button btnGuardar = findViewById(R.id.btnGuardar);
        btnGuardar.setOnClickListener(v -> {
            if (empleado == null) empleado = new Empleado();
            empleado.setNombre(etNombre.getText().toString());
            empleado.setTipo(etTipo.getText().toString());
            empleado.setEdad(Integer.parseInt(etEdad.getText().toString()));
            empleado.setImagen(etImagen.getText().toString());

            Intent result = new Intent();
            result.putExtra("empleado", empleado);
            result.putExtra("position", position);
            setResult(RESULT_OK, result);
            finish();
        });
    }
}
