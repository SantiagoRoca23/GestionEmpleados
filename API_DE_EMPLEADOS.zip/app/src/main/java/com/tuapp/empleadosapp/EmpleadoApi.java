package com.tuapp.empleadosapp;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.DELETE;
import retrofit2.http.Path;
import retrofit2.http.Body;

public interface EmpleadoApi {
    @GET("empleados.json")
    Call<List<Empleado>> getEmpleados();

    @GET("empleados/{id}.json")
    Call<Empleado> getEmpleado(@Path("id") int id);

    @POST("empleados.json")
    Call<Empleado> crearEmpleado(@Body Empleado empleado);

    @PUT("empleados/{id}.json")
    Call<Empleado> actualizarEmpleado(@Path("id") int id, @Body Empleado empleado);

    @DELETE("empleados/{id}.json")
    Call<Void> eliminarEmpleado(@Path("id") int id);
}