package com.tuapp.empleadosapp;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.List;

public class EmpleadoAdapter extends RecyclerView.Adapter<EmpleadoAdapter.ViewHolder> {
    private List<Empleado> empleados;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Empleado empleado);
        void onEditClick(Empleado empleado, int position);
        void onDeleteClick(Empleado empleado, int position);
    }

    public EmpleadoAdapter(List<Empleado> empleados, OnItemClickListener listener) {
        this.empleados = empleados;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_empleado, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Empleado empleado = empleados.get(position);
        holder.tvNombre.setText(empleado.getNombre());
        holder.tvTipo.setText(empleado.getTipo());
        holder.tvEdad.setText(String.valueOf(empleado.getEdad()));
        Glide.with(holder.itemView.getContext()).load(empleado.getImagen()).into(holder.ivImagen);

        holder.itemView.setOnClickListener(v -> listener.onItemClick(empleado));
        holder.btnEditar.setOnClickListener(v -> listener.onEditClick(empleado, position));
        holder.btnEliminar.setOnClickListener(v -> listener.onDeleteClick(empleado, position));
    }

    @Override
    public int getItemCount() {
        return empleados.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvTipo, tvEdad;
        ImageView ivImagen;
        ImageButton btnEditar, btnEliminar;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvTipo = itemView.findViewById(R.id.tvTipo);
            tvEdad = itemView.findViewById(R.id.tvEdad);
            ivImagen = itemView.findViewById(R.id.ivImagen);
            btnEditar = itemView.findViewById(R.id.btnEditar);
            btnEliminar = itemView.findViewById(R.id.btnEliminar);
        }
    }
}
