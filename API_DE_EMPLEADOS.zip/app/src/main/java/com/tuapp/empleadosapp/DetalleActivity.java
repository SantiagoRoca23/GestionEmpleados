package com.tuapp.empleadosapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;

public class DetalleActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        Empleado empleado = (Empleado) getIntent().getSerializableExtra("empleado");
        if (empleado == null) {
            finish();
            return;
        }

        TextView tvNombre = findViewById(R.id.tvNombre);
        TextView tvTipo = findViewById(R.id.tvTipo);
        TextView tvEdad = findViewById(R.id.tvEdad);
        ImageView ivImagen = findViewById(R.id.ivImagen);

        tvNombre.setText(empleado.getNombre());
        tvTipo.setText(empleado.getTipo());
        tvEdad.setText(String.valueOf(empleado.getEdad()));
        Glide.with(this).load(empleado.getImagen()).into(ivImagen);
    }
}
