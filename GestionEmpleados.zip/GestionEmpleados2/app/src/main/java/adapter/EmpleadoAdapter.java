package adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.tuapp.gestionempleados.DetalleActivity;
import com.tuapp.gestionempleados.R;
import model.Empleado;

import java.util.List;

public class EmpleadoAdapter extends RecyclerView.Adapter<EmpleadoAdapter.ViewHolder> {

    private final List<Empleado> lista;
    private final Context context;

    public EmpleadoAdapter(List<Empleado> lista, Context context) {
        this.lista = lista;
        this.context = context;
    }

    @NonNull
    @Override
    public EmpleadoAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_empleado, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EmpleadoAdapter.ViewHolder holder, int position) {
        Empleado empleado = lista.get(position);

        holder.tvTipo.setText(empleado.getTipo());
        holder.tvNombre.setText(empleado.getNombre() + " " + empleado.getApellido());
        holder.tvDetalles.setText(empleado.getDetalles());

        switch (empleado.getTipo()) {
            case "Gerente":
                holder.itemView.setBackgroundColor(Color.parseColor("#FFD700"));
                break;
            case "Técnico":
                holder.itemView.setBackgroundColor(Color.parseColor("#ADD8E6"));
                break;
            case "Técnico Senior":
                holder.itemView.setBackgroundColor(Color.parseColor("#98FB98"));
                break;
        }

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetalleActivity.class);
            intent.putExtra("tipo", empleado.getTipo());
            intent.putExtra("nombre", empleado.getNombre());
            intent.putExtra("apellido", empleado.getApellido());
            intent.putExtra("detalles", empleado.getDetalles());

            if (empleado instanceof model.TecnicoSenior) {
                String img = ((model.TecnicoSenior) empleado).getImg();
                intent.putExtra("img", img);
            }


            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvTipo, tvNombre, tvDetalles;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTipo = itemView.findViewById(R.id.tvTipo);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvDetalles = itemView.findViewById(R.id.tvDetalles);
        }
    }
}
