package com.tuapp.gestionempleados;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import adapter.EmpleadoAdapter;
import model.Empleado;
import model.Gerente;
import model.Tecnico;
import model.TecnicoSenior;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EmpleadoAdapter adapter;
    private List<Empleado> listaEmpleados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listaEmpleados = new ArrayList<>();
        cargarEmpleados();

        adapter = new EmpleadoAdapter(listaEmpleados, this);
        recyclerView.setAdapter(adapter);
    }

    private void cargarEmpleados() {
        listaEmpleados.add(new Gerente(1, "Lucía", "Pérez", 4500.0, "2021-01-12", "Marketing", 1200, 5));
        listaEmpleados.add(new Tecnico(2, "Carlos", "Martínez", 3000.0, "2022-05-10", "Redes", "Intermedio", 12));
        listaEmpleados.add(new Tecnico(3, "Ana", "Rojas", 3100.0, "2020-11-22", "Soporte", "Avanzado", 10));
        listaEmpleados.add(new TecnicoSenior(4, "Diego", "Salazar", 3500.0, "2019-09-30", "Desarrollo", "Avanzado", 15, 20, 50, "senior1"));
        listaEmpleados.add(new Gerente(5, "Elena", "Morales", 4700.0, "2018-04-01", "Ventas", 1300, 7));
    }
}
