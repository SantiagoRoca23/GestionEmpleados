package com.tuapp.gestionempleados;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetalleActivity extends AppCompatActivity {

    private TextView tvDetalleTitulo, tvDetalleContenido;
    private ImageView imgEmpleado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        tvDetalleTitulo = findViewById(R.id.tvDetalleTitulo);
        tvDetalleContenido = findViewById(R.id.tvDetalleContenido);
        imgEmpleado = findViewById(R.id.imgEmpleado);

        String tipo = getIntent().getStringExtra("tipo");
        String nombre = getIntent().getStringExtra("nombre");
        String apellido = getIntent().getStringExtra("apellido");
        String detalles = getIntent().getStringExtra("detalles");
        String img = getIntent().getStringExtra("img");

        tvDetalleTitulo.setText(tipo + ": " + nombre + " " + apellido);
        tvDetalleContenido.setText(detalles);

        if (tipo.equals("Técnico Senior") && img != null && !img.isEmpty()) {
            int resId = getResources().getIdentifier(img, "drawable", getPackageName());
            if (resId != 0) {
                imgEmpleado.setImageResource(resId);
                imgEmpleado.setVisibility(ImageView.VISIBLE);
            }
        }
    }
}
