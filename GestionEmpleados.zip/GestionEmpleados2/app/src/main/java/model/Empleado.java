package model;

public abstract class Empleado {
    protected int id;
    protected String nombre;
    protected String apellido;
    protected double salarioBase;
    protected String fechaContratacion;

    public Empleado(int id, String nombre, String apellido, double salarioBase, String fechaContratacion) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.salarioBase = salarioBase;
        this.fechaContratacion = fechaContratacion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public String getFechaContratacion() {
        return fechaContratacion;
    }

    public abstract String getTipo();
    public abstract String getDetalles();
}