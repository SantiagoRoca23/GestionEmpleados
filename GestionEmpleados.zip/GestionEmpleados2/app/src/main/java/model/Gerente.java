package model;

public class Gerente extends Empleado {
    private String departamento;
    private double bonoAnual;
    private int cantidadSubordinados;

    public Gerente(int id, String nombre, String apellido, double salarioBase, String fechaContratacion,
                   String departamento, double bonoAnual, int cantidadSubordinados) {
        super(id, nombre, apellido, salarioBase, fechaContratacion);
        this.departamento = departamento;
        this.bonoAnual = bonoAnual;
        this.cantidadSubordinados = cantidadSubordinados;
    }

    @Override
    public String getTipo() {
        return "Gerente";
    }

    @Override
    public String getDetalles() {
        return "Departamento: " + departamento + "\nBono: " + bonoAnual + "\nSubordinados: " + cantidadSubordinados;
    }
}
