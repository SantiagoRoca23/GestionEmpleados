package model;

public class TecnicoSenior extends Tecnico {
    private int proyectosCompletados;
    private int clientesAtendidos;
    private int valor = 20000;
    private String img;

    public TecnicoSenior(int id, String nombre, String apellido, double salarioBase, String fechaContratacion,
                         String especialidad, String nivelCertificacion, int horasExtra,
                         int proyectosCompletados, int clientesAtendidos, String img) {
        super(id, nombre, apellido, salarioBase, fechaContratacion, especialidad, nivelCertificacion, horasExtra);
        this.proyectosCompletados = proyectosCompletados;
        this.clientesAtendidos = clientesAtendidos;
        this.img = img;
    }

    @Override
    public String getTipo() {
        return "Técnico Senior";
    }

    @Override
    public String getDetalles() {
        return super.getDetalles() +
                "\nProyectos: " + proyectosCompletados +
                "\nClientes: " + clientesAtendidos +
                "\nValor: " + valor;
    }

    public String getImg() {
        return img;
    }
}
