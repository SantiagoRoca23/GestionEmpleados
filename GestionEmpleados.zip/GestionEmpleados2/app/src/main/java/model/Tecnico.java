package model;

public class Tecnico extends Empleado {
    private String especialidad;
    private String nivelCertificacion;
    private int horasExtra;

    public Tecnico(int id, String nombre, String apellido, double salarioBase, String fechaContratacion,
                   String especialidad, String nivelCertificacion, int horasExtra) {
        super(id, nombre, apellido, salarioBase, fechaContratacion);
        this.especialidad = especialidad;
        this.nivelCertificacion = nivelCertificacion;
        this.horasExtra = horasExtra;
    }

    @Override
    public String getTipo() {
        return "Técnico";
    }

    @Override
    public String getDetalles() {
        return "Especialidad: " + especialidad + "\nCertificación: " + nivelCertificacion + "\nHoras Extra: " + horasExtra;
    }
}
